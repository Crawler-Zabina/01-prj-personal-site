/**********************************************************
 * Project 1: Art Rating System
 * Written by: Sabine Major
 *
 * This program stores artworks in a generic circular doubly
 * linked list. Artists can add or remove artworks, while
 * visitors can browse the carousel and rate each artwork.
 **********************************************************/

#include <limits>
#include <string>
#include <cctype>
#include <iostream>

using namespace std;


/********************************
 * ARTWORK CLASS
 * Blueprint for one artwork entry
 *******************************/
class Artwork {
private:
    unsigned int id;
    string title;
    string imageUrl;
    int starTotal;
    int votes;

public:
    // Creates one new artwork with no ratings.
    Artwork(unsigned int startingId,
            string startingTitle,
            string startingImageUrl)
        : id(startingId),
          title(startingTitle),
          imageUrl(startingImageUrl),
          starTotal(0),
          votes(0) {
    }

    // Returns the permanent ID assigned to this artwork.
    unsigned int getId() const {
        return id;
    }

    // Returns the artwork title.
    string getTitle() const {
        return title;
    }

    // Returns the URL associated with the artwork image.
    string getImageUrl() const {
        return imageUrl;
    }

    // Returns the number of ratings submitted for this artwork.
    int getVotes() const {
        return votes;
    }

    // Returns the sum of all star ratings submitted for this artwork.
    int getRatingTotal() const {
        return starTotal;
    }

    // Calculates the average rather than storing a separate average value.
    double getAverageRating() const {
        if (votes == 0) {
            return 0.0;
        }

        return static_cast<double>(starTotal) / votes;
    }

    // Asks for one rating and stores it only if it is between 1 and 5.
    bool addRating() {
        int stars = 0;

        cout << "Rate this artwork from 1 to 5 stars: ";

        if (!(cin >> stars)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Error: Please enter a whole number from 1 to 5." << endl;
            return false;
        }

        if (stars < 1 || stars > 5) {
            cout << "Error: Entry must be between 1 and 5." << endl;
            return false;
        }

        starTotal += stars;
        votes++;
        return true;
    }

    // Displays the information for one artwork.
    void displayArtwork() const {
        cout << "\nID: " << id << endl;
        cout << "Title: " << title << endl;
        cout << "Image URL: " << imageUrl << endl;
        cout << "Rating total: " << getRatingTotal() << " star(s)" << endl;
        cout << "Number of votes: " << votes << endl;

        if (votes > 0) {
            cout << "Average Rating: "
                 << getAverageRating()
                 << " out of 5 stars."
                 << endl;
        }
        else {
            cout << "This artwork has no ratings yet!" << endl;
        }
    }
};

/**********************************************************
 * ARTIST INPUT
 * Creates Artwork objects with automatically generated IDs
 *********************************************************/
unsigned int nextId = 1;

Artwork enterArtwork() {
    string enteredTitle;
    string enteredImageUrl;

    cout << "Please enter an artwork title: ";
    getline(cin >> ws, enteredTitle);

    cout << "Please enter an image URL: ";
    getline(cin, enteredImageUrl);

    unsigned int assignedId = nextId;
    nextId++;

    return Artwork(assignedId, enteredTitle, enteredImageUrl);
}

/**********************************************************
 * GENERIC CIRCULAR DOUBLY LINKED LIST
 * Stores an arbitrary item type selected through the template
 *********************************************************/
template <typename ItemType>
class DoublyCircularLinkedList {
private:
    // Each node stores one item and links to both neighboring nodes.
    struct Node {
        ItemType item;
        Node* next;
        Node* prev;

        Node(const ItemType& startingItem)
            : item(startingItem),
              next(nullptr),
              prev(nullptr) {
        }
    };

    Node* head;
    Node* tail;
    Node* current;
    int itemCount;

public:
    // Creates an empty list.
    DoublyCircularLinkedList()
        : head(nullptr),
          tail(nullptr),
          current(nullptr),
          itemCount(0) {
    }

    // Prevents accidental shallow copies of a list that owns dynamic nodes.
    DoublyCircularLinkedList(const DoublyCircularLinkedList&) = delete;
    DoublyCircularLinkedList& operator=(const DoublyCircularLinkedList&) = delete;

    // Adds a new node between the old tail and the head.
    void add(const ItemType& newItem) {
        Node* newNode = new Node(newItem);

        if (head == nullptr) {
            head = newNode;
            tail = newNode;
            current = newNode;

            newNode->next = newNode;
            newNode->prev = newNode;
        }
        else {
            newNode->next = head;
            newNode->prev = tail;
            tail->next = newNode;
            head->prev = newNode;
            tail = newNode;
        }

        itemCount++;
    }

    // Removes the current node and moves current to the following node.
    bool removeCurrent() {
        if (current == nullptr) {
            return false;
        }

        Node* nodeToDelete = current;

        // Removing the only node leaves the list empty.
        if (itemCount == 1) {
            delete nodeToDelete;
            head = nullptr;
            tail = nullptr;
            current = nullptr;
            itemCount = 0;
            return true;
        }

        // Join the nodes before and after the removed node.
        Node* nextNode = nodeToDelete->next;
        nodeToDelete->prev->next = nextNode;
        nextNode->prev = nodeToDelete->prev;

        // Update head or tail if either one is being removed.
        if (nodeToDelete == head) {
            head = nextNode;
        }

        if (nodeToDelete == tail) {
            tail = nodeToDelete->prev;
        }

        current = nextNode;
        delete nodeToDelete;
        itemCount--;
        return true;
    }

    // Reports whether the list contains no nodes.
    bool isEmpty() const {
        return head == nullptr;
    }

    // Returns the stored node count in constant O(1) time.
    int getItemCount() const {
        return itemCount;
    }

    // Returns the item stored in the current node, or nullptr for an empty list.
    ItemType* getCurrent() {
        if (current == nullptr) {
            return nullptr;
        }

        return &(current->item);
    }

    // Moves one node forward. Circular links wrap the tail back to the head.
    bool moveNext() {
        if (current == nullptr) {
            return false;
        }

        current = current->next;
        return true;
    }

    // Moves one node backward. Circular links wrap the head back to the tail.
    bool movePrevious() {
        if (current == nullptr) {
            return false;
        }

        current = current->prev;
        return true;
    }

    // Deletes every dynamically allocated node when the list is destroyed.
    ~DoublyCircularLinkedList() {
        if (head == nullptr) {
            return;
        }

        Node* nodeToDelete = head->next;

        while (nodeToDelete != head) {
            Node* nextNode = nodeToDelete->next;
            delete nodeToDelete;
            nodeToDelete = nextNode;
        }

        delete head;
        head = nullptr;
        tail = nullptr;
        current = nullptr;
        itemCount = 0;
    }
};

/**********************************************************
 * ARTIST ACTION
 * Collects one artwork and adds it to the portfolio
 *********************************************************/
void artistAddArtwork(DoublyCircularLinkedList<Artwork>& portfolio) {
    Artwork newArtwork = enterArtwork();
    portfolio.add(newArtwork);

    cout << "Artwork \""
         << newArtwork.getTitle()
         << "\" (ID "
         << newArtwork.getId()
         << ") was added successfully. The portfolio now contains "
         << portfolio.getItemCount()
         << " artwork(s)."
         << endl;
}

/**********************************************************
 * ARTIST DISPLAY ACTION
 * Displays every artwork entry without changing the list
 *********************************************************/
void displayAllArtworks(DoublyCircularLinkedList<Artwork>& portfolio) {
    if (portfolio.isEmpty()) {
        cout << "The portfolio is empty. Add an artwork first." << endl;
        return;
    }

    cout << "\n===== ALL ARTWORK ENTRIES =====" << endl;

    // Moving exactly itemCount times returns current to its starting node.
    for (int displayedCount = 0;
         displayedCount < portfolio.getItemCount();
         displayedCount++) {
        portfolio.getCurrent()->displayArtwork();
        portfolio.moveNext();
    }

    cout << "\nTotal artworks: " << portfolio.getItemCount() << endl;
}

/**********************************************************
 * ARTIST REMOVAL ACTION
 * Lets the artist browse and remove an incorrect entry
 *********************************************************/
void artistRemoveArtwork(DoublyCircularLinkedList<Artwork>& portfolio) {
    if (portfolio.isEmpty()) {
        cout << "The portfolio is empty. There is nothing to remove." << endl;
        return;
    }

    char artistChoice;

    do {
        Artwork* currentArtwork = portfolio.getCurrent();
        currentArtwork->displayArtwork();

        cout << "\nArtist removal options:" << endl;
        cout << "N - Next artwork" << endl;
        cout << "P - Previous artwork" << endl;
        cout << "D - Delete this artwork" << endl;
        cout << "Q - Return to the main menu" << endl;
        cout << "Enter your choice: ";
        cin >> artistChoice;

        artistChoice = static_cast<char>(
            toupper(static_cast<unsigned char>(artistChoice))
        );

        switch (artistChoice) {
            case 'N':
                portfolio.moveNext();
                break;

            case 'P':
                portfolio.movePrevious();
                break;

            case 'D': {
                char confirmation;

                cout << "Delete artwork ID "
                     << currentArtwork->getId()
                     << " (\"" << currentArtwork->getTitle() << "\")? Y/N: ";
                cin >> confirmation;

                confirmation = static_cast<char>(
                    toupper(static_cast<unsigned char>(confirmation))
                );

                if (confirmation == 'Y') {
                    portfolio.removeCurrent();
                    cout << "Artwork removed successfully. The portfolio now contains "
                         << portfolio.getItemCount()
                         << " artwork(s)."
                         << endl;

                    if (portfolio.isEmpty()) {
                        cout << "Returning to the main menu." << endl;
                        return;
                    }
                }
                else if (confirmation == 'N') {
                    cout << "Removal canceled." << endl;
                }
                else {
                    cout << "Invalid confirmation. The artwork was not removed." << endl;
                }
                break;
            }

            case 'Q':
                cout << "Returning to the main menu." << endl;
                break;

            default:
                cout << "Invalid choice. Enter N, P, D, or Q." << endl;
        }

    } while (artistChoice != 'Q');
}

/**********************************************************
 * VISITOR ACTIONS
 * Displays, navigates, and rates artworks in the carousel
 *********************************************************/
void visitorCarousel(DoublyCircularLinkedList<Artwork>& portfolio) {
    if (portfolio.isEmpty()) {
        cout << "The portfolio is empty. Add an artwork first." << endl;
        return;
    }

    char visitorChoice;

    do {
        Artwork* currentArtwork = portfolio.getCurrent();
        currentArtwork->displayArtwork();

        cout << "\nVisitor options:" << endl;
        cout << "N - Next artwork" << endl;
        cout << "P - Previous artwork" << endl;
        cout << "R - Rate this artwork" << endl;
        cout << "Q - Return to the main menu" << endl;
        cout << "Enter your choice: ";
        cin >> visitorChoice;

        visitorChoice = static_cast<char>(
            toupper(static_cast<unsigned char>(visitorChoice))
        );

        switch (visitorChoice) {
            case 'N':
                portfolio.moveNext();
                break;

            case 'P':
                portfolio.movePrevious();
                break;

            case 'R':
                if (currentArtwork->addRating()) {
                    cout << "Rating added successfully." << endl;
                }
                break;

            case 'Q':
                cout << "Returning to the main menu." << endl;
                break;

            default:
                cout << "Invalid choice. Enter N, P, R, or Q." << endl;
        }

    } while (visitorChoice != 'Q');
}

/**********************************************************
 * MAIN FUNCTION
 * Separates artist actions from visitor actions
 *********************************************************/
int main() {
    // The template type becomes Artwork for this list instance.
    DoublyCircularLinkedList<Artwork> portfolio;
    int mainChoice = 0;

    do {
        cout << "\n===== ART RATING SYSTEM =====" << endl;
        cout << "1 - Artist: Add an artwork" << endl;
        cout << "2 - Artist: Display all artwork entries" << endl;
        cout << "3 - Artist: Remove an artwork" << endl;
        cout << "4 - Visitor: Browse and rate artworks" << endl;
        cout << "5 - Exit" << endl;
        cout << "Enter your choice: ";

        if (!(cin >> mainChoice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Enter 1, 2, 3, 4, or 5." << endl;
            continue;
        }

        switch (mainChoice) {
            case 1:
                artistAddArtwork(portfolio);
                break;

            case 2:
                displayAllArtworks(portfolio);
                break;

            case 3:
                artistRemoveArtwork(portfolio);
                break;

            case 4:
                visitorCarousel(portfolio);
                break;

            case 5:
                cout << "Exiting the program." << endl;
                break;

            default:
                cout << "Invalid choice. Enter 1, 2, 3, 4, or 5." << endl;
        }

    } while (mainChoice != 5);

    return 0;
}
